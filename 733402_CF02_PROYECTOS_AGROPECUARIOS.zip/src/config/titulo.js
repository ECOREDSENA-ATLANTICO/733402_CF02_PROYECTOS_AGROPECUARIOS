module.exports =
  'Formulación de proyectos agropecuarios bajo el enfoque metodológico de marco lógico'
